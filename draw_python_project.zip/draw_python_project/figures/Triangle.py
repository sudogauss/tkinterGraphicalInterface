from figures.Point import Point


class Triangle:

    def __init__(self, peak1_x, peak1_y, peak2_x, peak2_y, peak3_x, peak3_y):
        self.vertex1 = Point(peak1_x, peak1_y)
        self.vertex2 = Point(peak2_x, peak2_y)
        self.vertex3 = Point(peak3_x, peak3_y)
        self.canvas_object = None

    def set_canvas_object(self, canvas_object):
        self.canvas_object = canvas_object

    def distance(self, point):
        d1 = self.vertex1.distance(point)